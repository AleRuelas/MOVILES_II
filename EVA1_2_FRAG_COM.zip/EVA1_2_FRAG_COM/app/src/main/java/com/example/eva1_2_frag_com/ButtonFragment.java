package com.example.eva1_2_frag_com;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
//Recurperar el man

//Recuperar el componente
//Llamar al metodo

/**
 * A simple {@link Fragment} subclass.
 */
public class ButtonFragment extends Fragment {
    MainActivity main;

    Button btnAlgo;
    public ButtonFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        LinearLayout linearLayout = (LinearLayout)inflater.inflate(R.layout.fragment_button, container, false);
        btnAlgo = linearLayout.findViewById(R.id.btn);
        btnAlgo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                main.onMessageFromFragToMain("Boton", "Fragmento con Boton");
            }
        });
        return linearLayout;
    }
//NO HACER COMUNICACION DE FRAGMENTO A FRAGMENTO, SINO DE FRAGMENTO A MAIN
    public void onMessageFromMainToFrag(String param){

        btnAlgo.setText(param);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        main =  (MainActivity) getActivity();
    }


}

package com.example.eva1_2_frag_com;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListFragment extends Fragment {
    String[] datos = {"Enero",
            "Febrero",
            "Marzo",
            "Abril",
            "Mayo",
            "Junio",
            "Julio",
            "Agosto",
            "Septiembre",
            "Octubre",
            "Noviembre",
            "Dieciembre"};

    //No se requiere el Attach para recuperar el contexto
    MainActivity main;

    public ListFragment() {
        // Required empty public constructor
    }

//Crea la lista del frameLayout
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        FrameLayout frameLayout = (FrameLayout)inflater.inflate(R.layout.fragment_list, container, false);
        ListView list = frameLayout.findViewById(R.id.listDatos);
        list.setAdapter(new ArrayAdapter<String>(
                main,
                android.R.layout.simple_list_item_1,
                datos
        ));
        //Responder al click
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                main.onMessageFromFragToMain("Lista", datos[i] );
            }
        });
        return  frameLayout;

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Recuperar la actividad principal
        main = (MainActivity)getActivity();

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }
}

package com.example.eva1_2_frag_com;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ButtonFragment btnFragment;
    ListFragment listFragment;
    TextView txtMensa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtMensa = findViewById(R.id.txtMensa);


    }
//Se ejecuta cuando un fragmento se conecta a la actividad
    //Todo se resuelve haciendo metodos o funciones que haga esa funcion, se puede hacer directamente pero no se recomienda
    @Override
    public void onAttachFragment(Fragment fragment) {
        super.onAttachFragment(fragment);
        if(fragment.getClass() == ButtonFragment.class){
            btnFragment = (ButtonFragment)fragment;
        }else if (fragment.getClass() == ListFragment.class){
            listFragment = (ListFragment)fragment;
        }
    }
                                    //quie y que estamos enviando
    public void onMessageFromFragToMain(String Sender, String param ){
        if (Sender.equals("Lista")){
            txtMensa.setText("Lista: "+ param);
            btnFragment.onMessageFromMainToFrag(param);
        } else if (Sender.equals("Boton")){
            txtMensa.setText("Boton: "+param);
            btnFragment.onMessageFromMainToFrag(param);
        }
    }
}

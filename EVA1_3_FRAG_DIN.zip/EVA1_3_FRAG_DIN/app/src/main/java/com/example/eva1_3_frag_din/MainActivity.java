package com.example.eva1_3_frag_din;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void click1(View view){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        oneFragment one = new oneFragment();
        ft.replace(R.id.fragFrame, one);
        ft.commit();
    }
    public void click2 (View view){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        twoFragment two = new twoFragment();
        ft.replace(R.id.fragFrame, two);
        ft.commit();
    }

}

package com.example.eva1_4_frag_din_orienta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
//Esta el frameLayour creado?
//
    FrameLayout frmLyDetail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onMessageFromFragToMain (){
        frmLyDetail =  findViewById(R.id.frmLayDetail);
        if(frmLyDetail != null){//LANDSCAPE
            //CREAR EL FRAGMENTO 2 DINAMICAMENTE
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            TwoFragment two = new TwoFragment();
            two.setParam("ESTE MENSAJE TAMBIEN");
            ft.replace(R.id.frmLayDetail, two);
            ft.commit();
            //two.onMessageFromMainToFrag("Este mensaje tambien");NO FUNCIONA POR QUE LE FRAGMENTO HA SIDO CREADO

            Toast.makeText(this,"LANDSCAPE",Toast.LENGTH_LONG).show();

//ESTATICO
        }else{//PORTRAIT
            //LANZAR LA ACTIVIDAD SECUNDARIA CON INTENTO QUE INCLUYA EL TWOFRAGMENT
            Toast.makeText(this,"PORTRAIT",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, Secundaria.class);
            intent.putExtra("MENSAJE", "ESTE ES EL MENSAJE");
            startActivity(intent);

        }
    }
}

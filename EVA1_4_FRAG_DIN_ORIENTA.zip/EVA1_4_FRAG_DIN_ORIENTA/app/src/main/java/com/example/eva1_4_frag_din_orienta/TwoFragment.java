package com.example.eva1_4_frag_din_orienta;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

/*
Para enviar informacion de inicio
Para lograr recibir el mensaje, hay que hacer uso de los metodos get y set, o hacer uso de un contructor
Desde el main se envia el parametro setParam("Mensaje a enviar")
Ya solo desde el fragmento hay que usarlo

Cuando se modifica posteriormente el fragmento se pueden enviar datos desde el metodo onAttachFragment
 */
/**
 * A simple {@link Fragment} subclass.
 */
public class TwoFragment extends Fragment {
    TextView frag2;
    private String param;

    public TwoFragment() {
        // Required empty public constructor
    }

    public String getParam() {

        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        FrameLayout frameLayout = (FrameLayout) inflater.inflate(R.layout.fragment_two, container, false);
    frag2 = frameLayout.findViewById(R.id.txtTwo);
    onMessageFromMainToFrag(param);
    return frameLayout;

    }

    public void onMessageFromMainToFrag(String param){
        frag2.setText(param);
    }


}

package com.example.eva1_5_clima_fragmentos;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ClimaAdapter extends ArrayAdapter<ClimaFragment> {
    Context context;
    int resource;
    ClimaFragment[] cCiudades;

    public ClimaAdapter(Context context, int resource, ClimaFragment[] objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.cCiudades = objects;
    }
    //Construye la vista
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageClima;
        TextView txtVwCiudad, txtVwTemp, txtVwClima;

        //ConvertView es el layout que representa una fila en la lista
        if (convertView == null) {
            //Crear nuestro layout
            //Inflater
            LayoutInflater llInflater = ((Activity)context).getLayoutInflater();
            convertView = llInflater.inflate(resource, parent, false); //Adaptador
        }
        imageClima = convertView.findViewById(R.id.imageClima);
        txtVwCiudad = convertView.findViewById(R.id.textViewCiudad);
        txtVwTemp = convertView.findViewById(R.id.textViewTemp);
        txtVwClima = convertView.findViewById(R.id.textViewClima);

        imageClima.setImageResource(cCiudades[position].getImagen());
        txtVwCiudad.setText(cCiudades[position].getCiudad());
        txtVwTemp.setText(cCiudades[position].getTemp() + " C");
        txtVwClima.setText(cCiudades[position].getClima());

        return convertView;


    }


}

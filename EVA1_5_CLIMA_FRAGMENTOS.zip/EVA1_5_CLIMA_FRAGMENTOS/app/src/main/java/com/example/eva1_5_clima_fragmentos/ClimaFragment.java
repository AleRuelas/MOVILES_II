package com.example.eva1_5_clima_fragmentos;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ClimaFragment extends Fragment {
    MainActivity main;
    ImageView imageView;
    TextView txtCiudad, txtTemp, txtClima;
    private int imagen;
    private String ciudad;
    private double temp;
    private String clima;

    public ClimaFragment() {
        // Required empty public constructor
    }

    public ClimaFragment(int imagen, String ciudad, double temp, String clima) {
        this.imagen = imagen;
        this.ciudad = ciudad;
        this.temp = temp;
        this.clima = clima;
    }

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public double getTemp() {
        return temp;
    }

    public void setTemp(double temp) {
        this.temp = temp;
    }

    public String getClima() {
        return clima;
    }

    public void setClima(String clima) {
        this.clima = clima;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        LinearLayout linearLayout = (LinearLayout)inflater.inflate(R.layout.fragment_clima, container, false);
        imageView = linearLayout.findViewById(R.id.imageClima);
        txtCiudad = linearLayout.findViewById(R.id.textViewCiudad);
        txtClima = linearLayout.findViewById(R.id.textViewClima);
        txtTemp = linearLayout.findViewById(R.id.textViewTemp);

        imageView.setImageResource(getImagen());
        txtCiudad.setText(getCiudad());
        txtClima.setText(getClima());
        txtTemp.setText(getTemp() + " °C");
        return linearLayout;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        main = (MainActivity) getActivity();
    }
}

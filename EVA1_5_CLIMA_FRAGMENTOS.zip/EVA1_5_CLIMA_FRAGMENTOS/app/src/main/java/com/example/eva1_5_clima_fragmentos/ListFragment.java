package com.example.eva1_5_clima_fragmentos;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListFragment extends Fragment {
    ListView listaClima;
    MainActivity main;

    ClimaFragment[] cCiudades = {
            new ClimaFragment(R.drawable.atmospher,"Aldama", 25,"chido" ),
            new ClimaFragment(R.drawable.cloudy,"Camargo", 28,"Nice!" ),
            new ClimaFragment(R.drawable.light_rain,"Parral", 18.5,"Lluvioso" ),
            new ClimaFragment(R.drawable.rainy,"Madera", 17,"Melancolico" ),
            new ClimaFragment(R.drawable.snow,"Creel", -7,"Nevadas" ),
            new ClimaFragment(R.drawable.thunderstorm,"Jimenez", 16,":Lluvias intensas" ),
            new ClimaFragment(R.drawable.tornado,"Delicias", 26,"Run like hell" )
    };

    public ListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        FrameLayout frameLayout = (FrameLayout) inflater.inflate(R.layout.fragment_list, container, false);
        listaClima = frameLayout.findViewById(R.id.listaClima);
        listaClima.setAdapter(new ClimaAdapter(main, R.layout.fragment_clima, cCiudades));

        listaClima.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                main.fromFragToMain(cCiudades[i].getImagen(), cCiudades[i].getCiudad(), cCiudades[i].getClima(), cCiudades[i].getTemp());
            }
        });


        return frameLayout;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        main = (MainActivity)getActivity();
    }
}

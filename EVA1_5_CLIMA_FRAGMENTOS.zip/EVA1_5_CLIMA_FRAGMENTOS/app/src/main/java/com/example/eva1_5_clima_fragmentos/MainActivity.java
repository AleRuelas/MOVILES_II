package com.example.eva1_5_clima_fragmentos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

public class MainActivity extends AppCompatActivity {

    ListFragment listFragment;
    ClimaFragment climaFragment;
    Clima clima;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        listFragment = new ListFragment();
        ft.replace(R.id.frameL, listFragment);
        ft.commit();
    }


    public void fromFragToMain(int i, String c, String cl, double t) {
        ClimaFragment climaFragment = new ClimaFragment();
        climaFragment.setImagen(i);
        climaFragment.setCiudad(c);
        climaFragment.setClima(cl);
        climaFragment.setTemp(t);

        FragmentTransaction ft2 = getSupportFragmentManager().beginTransaction();
        ft2.replace(R.id.frameL, climaFragment);
        ft2.addToBackStack("Clima");
        ft2.commit();
    }
}

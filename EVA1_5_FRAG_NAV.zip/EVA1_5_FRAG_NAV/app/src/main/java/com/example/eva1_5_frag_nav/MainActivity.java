package com.example.eva1_5_frag_nav;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        //ft.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right,android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        ft.setCustomAnimations(R.anim.anim_enter,R.anim.anim_exit,R.anim.anim_enter,R.anim.anim_exit);
        //Crear fragmento
        OneFragment oneFragment = new OneFragment();
        //Crear el listener
        oneFragment.setMiClickLis(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft2 = getSupportFragmentManager().beginTransaction();
                //Transiciones
                //ft2.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out,android.R.anim.fade_in, android.R.anim.fade_out);
                ft2.setCustomAnimations(R.anim.anim_enter,R.anim.anim_exit,R.anim.anim_enter,R.anim.anim_exit);
                TwoFragment twoFragment = new TwoFragment();
                ft2.replace(R.id.frameL, twoFragment);
                ft2.addToBackStack("Hola");
                ft2.commit();
            }
        });
        ft.replace(R.id.frameL, oneFragment);
        //ft.addToBackStack("Hola");
        ft.commit();

    }





}

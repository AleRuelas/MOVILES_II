package com.example.eva1_6_transiciones;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.transition.Fade;
import android.transition.Slide;
import android.view.View;
import android.view.Window;

public class MainActivity extends AppCompatActivity {
    Intent inLllamar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Activar la transicion, ytambien se puede hacer en XML
        getWindow().requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS);
        getWindow().setEnterTransition(new Fade().setDuration(5000));
        //getWindow().setExitTransition(new Slide().setDuration(5000));
        //getWindow().setExitTransition(new Fade().setDuration(5000));
        setContentView(R.layout.activity_main);
        inLllamar = new Intent(this, Main2Activity.class );
    }
    public void onClick(View view){
        startActivity(inLllamar, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());

    }
}
